import 'package:flutter/material.dart';

class Page2 extends StatelessWidget {
  Map extra = {};
  Page2({super.key, required this.extra});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Page 2"),
      ),
      body: Column(children: [
        Text(extra['name']),
        TextButton(
          onPressed: () {},
          child: Text("Go to page1"),
        )
      ]),
    );
  }
}
