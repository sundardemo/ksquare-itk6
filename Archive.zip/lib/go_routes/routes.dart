import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:myfirstapp/go_routes/page1.dart';
import 'package:myfirstapp/go_routes/page2.dart';

final router = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(
      path: '/',
      pageBuilder: (context, state) {
        return MaterialPage(child: Page1());
      },
    ),
    GoRoute(
      path: '/page1',
      pageBuilder: (context, state) {
        return MaterialPage(child: Page1());
      },
    ),
    GoRoute(
      path: '/page2',
      pageBuilder: (context, state) {
        return MaterialPage(
          child: Page2(
            extra: state.extra as Map,
          ),
        );
      },
    ),
  ],
);
