import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class Page1 extends StatelessWidget {
  const Page1({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Page 1"),
      ),
      body: Column(children: [
        TextButton(
          onPressed: () {
            context.go('/page2', extra: {'name': 'sundar'});
          },
          child: Text("Go to page2"),
        )
      ]),
    );
  }
}
