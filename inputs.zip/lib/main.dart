import 'package:flutter/material.dart';
import 'package:myfirstapp/screens/counter.dart';
import 'package:myfirstapp/screens/input_example.dart';
import 'package:myfirstapp/screens/list_view.dart';
import 'package:myfirstapp/screens/row_column.dart';
import 'package:myfirstapp/screens/stack_example.dart';

main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      home: InputExample(),
    ),
  );
}
